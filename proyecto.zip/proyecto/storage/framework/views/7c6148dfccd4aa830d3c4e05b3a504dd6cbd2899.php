<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $__env->yieldContent('titulo'); ?></title>
		<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
	</head>
	<body>
		<header class="container"><br>
				<nav class="nav">
					<ul class="breadcrumb">
						<li class="breadcrumb-item">
							<a class="" href=" <?php echo e(route('productos.index')); ?> ">Inicio</a>
						</li>
						<li class="breadcrumb-item">
							<a class="" href=" <?php echo e(route('productos.create')); ?> ">Add Producto</a>
						</li>
					</ul>
				</nav>
		</header>

		<?php echo $__env->yieldContent('contenido'); ?>

		<footer class="container h6" align="center">
			&copy;MULTIMEDIA 2021.
		</footer><br>
	</body>
</html><?php /**PATH C:\xampp\htdocs\proyecto\resources\views////plantillas/main.blade.php ENDPATH**/ ?>
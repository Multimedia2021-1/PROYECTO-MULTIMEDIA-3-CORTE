

<?php $__env->startSection('titulo'); ?>
	Detalle Producto
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container color" align="center">
		<div class="card" style="width: 18rem;">
			<div class="card-body">
				<div class="col-md-6 form-row">
					<div class="col">
						<label><strong>Nombre: </strong><?php echo e($producto->nombre); ?></label>
					</div>
					<div class="col">
						<label><strong>Peso: </strong><?php echo e($producto->peso); ?></label>
					</div>
				</div>
				<label><strong>Precio: </strong><?php echo e($producto->precio); ?></label>
			</div>
		</div><br>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../plantillas/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\resources\views/productos/show.blade.php ENDPATH**/ ?>
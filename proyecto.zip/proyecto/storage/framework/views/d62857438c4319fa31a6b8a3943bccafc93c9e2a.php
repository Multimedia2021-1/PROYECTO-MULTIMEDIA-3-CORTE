

<?php $__env->startSection('titulo'); ?>
	Editar Producto
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container color" align="center">
		<form action="<?php echo e(route('productos.update',$producto->id)); ?>" method="POST" accept-charset="utf-8" enctype="multipart/form-data"><br>
			<?php echo csrf_field(); ?> 
			<?php echo method_field('PUT'); ?>
			<div class="col-md-6">
				<input type="text" class="form-control" name="nombre" value="<?php echo e($producto->nombre); ?>"><br>
				<input type="text" class="form-control" name="peso" value="<?php echo e($producto->peso); ?>"><br>
				<input type="text" class="form-control" name="precio" value="<?php echo e($producto->precio); ?>"><br>
				<input type="submit" class="btn btn-primary" name="editar" value="Editar"><br>
			</div>
		</form><br>
	</div><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../plantillas/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\resources\views/productos/edit.blade.php ENDPATH**/ ?>